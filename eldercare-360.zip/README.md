# ElderCare 360 – Smart Elderly Care & Monitoring System

A modern, responsive, healthcare-themed web application designed for elderly care, real-time fall detection, medication compliance, daily routine tracking, caregiver monitoring, and IoT hardware integration (ESP32 + MPU-6050 6-DoF accelerometer & gyroscope).

---

## 🌟 Key Features

### 1. Dashboard (360° Health & Safety Overview)
- **Daily Health Overview**: High-level real-time summary cards for fall sensor status, daily walking progress, heart rate / blood pressure, and hydration levels.
- **Cardiovascular ECG Monitor**: Live animated pulse waveform synchronized with the senior's heart rate.
- **Medication Snapshot**: Quick view of next scheduled prescriptions with one-click "Take" action.
- **Senior Status Indicator**: Live status indicator (e.g. *"Arthur Pendelton • Room 204 • All Vitals Stable"*).

### 2. Fall Detection & Reversible Emergency Response
- **Real-Time Sensor Telemetry**: G-force impact waveform canvas plotting acceleration magnitude $V = \sqrt{a_x^2 + a_y^2 + a_z^2}$.
- **3D Sensor Orientation Visualizer**: Real-time 3D box showing senior body posture (Pitch and Roll angles).
- **Multi-Stage Detection Algorithm**:
  1. *Free-fall Phase* ($|a| < 0.5\text{g}$)
  2. *Impact Spike Phase* ($|a| > 3.2\text{g}$)
  3. *Inactivity Stillness Phase* (Pitch/Roll $> 60^\circ$ for $> 3$ seconds)
  4. *15-Second Emergency Countdown* with synthetic audio alarm siren and voice prompt.
- **Alert Cancellation**: Senior can tap **"I AM OK — CANCEL ALERT"** to stop the alarm, play a soothing resolution chime, and log a false alarm.
- **Escalation**: If countdown reaches 0 or if "SEND SOS NOW" is pressed, emergency SOS is dispatched to caregiver and EMS.

### 3. Medicine Reminders & Tablet Compliance
- **Filter Tabs**: All Prescriptions, Pending Today, Taken, Morning, Afternoon, Evening, Night.
- **Actions**: "Take Now", "Snooze 15 mins", and "Mark Missed".
- **Refill Tracking**: Visual warnings when bottle has $\le 15$ tablets remaining.
- **Add Medication Modal**: Form to add name, dosage, time slot, meal instructions, and refill bottle size.
- **Compliance Score**: Calculates real-time adherence rate (e.g., $92\%$).

### 4. Step & Physical Activity Tracking
- **Daily Goal Progress**: Animated circular SVG progress gauge tracking steps against daily goal (e.g., 6,000 steps).
- **Activity Metrics**: Steps, walking distance (km), active duration (minutes), and calorie burn (kcal).
- **Weekly Trend Chart**: 7-day comparison bar chart with goal line.
- **Interactive Walk Simulator**: "Simulate 10-Minute Walk (+250 steps)" button with goal completion celebration.

### 5. Health & Vitals Monitoring
- **Live Vitals Cards**: Heart Rate (BPM), Blood Pressure (Systolic / Diastolic), Body Temperature (°C / °F), SpO2 Oxygen (%), and Blood Glucose.
- **ECG Pulse Monitor**: Continuous canvas waveform with realistic P, Q, R, S, T wave anatomy.
- **Log Vitals Modal**: Record manual cuff readings with automatic history table updates.

### 6. Emergency SOS Center
- **Prominent Emergency SOS Button**: One-click tactile activation.
- **Emergency Contacts Directory**: Cards for Son (Michael), Daughter (Emily), Geriatrician (Dr. Sarah Adams), and 911 EMS.
- **Simulated Actions**: Immediate "📞 Call" and "✉️ Send SMS with GPS Pin" triggers.

### 7. Daily Routine & Wellness
- **Interactive Hydration Tracker**: 8 interactive water glasses; click to log 250ml glass with audio cues and hydration milestones.
- **Sleep Quality Tracker**: Sleep duration gauge (7.4 hours), score (84/100), and breakdown of Deep sleep, Light sleep, REM, and Awake periods.
- **Mobility Exercises**: Checkbox routine for gentle morning stretches and walking laps.
- **Doctor Appointments**: Add, view, and manage clinic visits with reminders.

### 8. Caregiver Portal
- **Remote Monitoring**: Senior safe status, current room location, and last check-in timestamp.
- **2-Way Message Notes**: Caregivers can type notes that appear on the senior's screen with chime and spoken voice!
- **Wellness Check-in**: One-click check-in logging.
- **Incident Audit Trail**: Full log of all fall alerts and resolutions.

### 9. Notification Hub
- Timestamped audit log of medication alerts, fall events, vitals warnings, and hardware events.
- Filterable and clearable.

### 10. Hardware Integration (ESP32 + MPU-6050)
- **Status Dashboard**: Microcontroller type, 6-Axis IMU status, battery level ($88\%$), and Wi-Fi RSSI ($-58\text{ dBm}$).
- **Live 3-Axis Stream**: Real-time canvas chart of raw $A_X, A_Y, A_Z$ acceleration streaming at $10\text{ Hz}$.
- **Zero-G Calibration**: Calibration button to tare tilt offsets.
- **Circuit Pinout Guide**: Complete wiring pinout table (ESP32 $\leftrightarrow$ MPU-6050).
- **Production-Ready Arduino / ESP32 C++ Sketch**: Copy-to-clipboard C++ sketch with HTTP client streaming to `/api/sensor`.

### 11. Interactive Demo Mode
Persistent top control bar allowing full demonstration of all emergency features without hardware:
- **Simulate Fall Event**: Triggers fall detection, alarm siren, 15-second radial countdown modal, cancellation, or SOS escalation.
- **Simulate Pill Alert**: Triggers audio chime and voice prompt for scheduled pill.
- **Add 350 Steps**: Animates progress gauge and milestones.
- **Fluctuate Vitals**: Toggles between normal resting vitals and elevated vitals.
- **Toggle Hardware Link**: Simulates ESP32 disconnect and reconnection.
- **Reset Demo**: Restores fresh baseline state.

### 12. Senior-Friendly Accessibility
- **A+ Large Text Mode**: Scales UI typography for elderly vision.
- **🌓 High Contrast Mode**: High contrast black/white/blue theme.
- **Synthesized Voice Guidance**: Web Speech API announces fall warnings and medicine alerts.
- **Synthetic Audio Engine**: Web Audio API generates sirens, chimes, and beeps without external MP3 files.

---

## 🚀 How to Run

### Method 1: Using the Included Python Server
Open terminal in `C:\Users\bhava\.gemini\antigravity\scratch\eldercare-360` and run:
```bash
python server.py
```
Then open [http://localhost:8000](http://localhost:8000) in your browser.

### Method 2: Double-click Launcher
Double-click `start_app.bat` inside the folder. It will start the server and open your default browser automatically.

### Method 3: Direct Browser Open (Offline File Mode)
You can directly open `index.html` in Chrome, Edge, Firefox, or Safari. All styles, icons, synthetic audio, and local storage work 100% standalone!

---

## 🔌 Hardware Setup (ESP32 + MPU-6050)

### Pinout Table:
| MPU-6050 Pin | ESP32 GPIO Pin | Function |
| :--- | :--- | :--- |
| **VCC** | 3.3V | Power Supply |
| **GND** | GND | Ground Reference |
| **SDA** | GPIO 21 | I2C Serial Data |
| **SCL** | GPIO 22 | I2C Serial Clock |
| **INT** | GPIO 19 | Motion Wake-up Interrupt |
| **Buzzer (+)** | GPIO 18 | Local Audible Alarm |
| **SOS Button** | GPIO 4 | Manual Hardware Push Button |

The complete, flashable Arduino sketch is available under the **ESP32 / MPU6050** tab in the web application.
