#!/usr/bin/env python3
"""
ElderCare 360 - Local Server & IoT Gateway for ESP32 / Arduino
Serves the web application and provides REST API endpoints for real hardware telemetry.
"""

import http.server
import socketserver
import json
import os
import sys
import webbrowser

PORT = 8000
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

# In-memory buffer for latest hardware telemetry
latest_hardware_telemetry = {
    "device": "ESP32-WROOM-32",
    "status": "Online",
    "ax": 0.05,
    "ay": -0.06,
    "az": 0.99,
    "gTotal": 1.01,
    "fall": 0,
    "last_updated": None
}

emergency_alerts = []

class ElderCareRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def do_GET(self):
        # API: Get latest sensor telemetry
        if self.path == '/api/sensor/latest':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(latest_hardware_telemetry).encode('utf-8'))
            return

        # API: Get server health
        elif self.path == '/api/health':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "running", "service": "ElderCare 360 Gateway"}).encode('utf-8'))
            return

        # Normal static file serving
        return super().do_GET()

    def do_POST(self):
        # API: ESP32 telemetry ingestion
        if self.path == '/api/sensor':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            try:
                data = json.loads(post_data.decode('utf-8'))
                latest_hardware_telemetry.update(data)
                import datetime
                latest_hardware_telemetry['last_updated'] = datetime.datetime.now().isoformat()
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "ok", "received": True}).encode('utf-8'))
                print(f"[ESP32 Telemetry] Total G: {data.get('gTotal')} | Fall Flag: {data.get('fall')}")
            except Exception as e:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode('utf-8'))
            return

        # API: Emergency SOS trigger from ESP32 push button
        elif self.path == '/api/alert':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            try:
                alert = json.loads(post_data.decode('utf-8'))
                emergency_alerts.append(alert)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "alert_dispatched"}).encode('utf-8'))
                print(f"[EMERGENCY ALERT] Source: {alert.get('source')} | Reason: {alert.get('reason')}")
            except Exception as e:
                self.send_response(400)
                self.end_headers()
            return

        self.send_response(404)
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

def run_server():
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), ElderCareRequestHandler) as httpd:
        print("=" * 60)
        print(" ElderCare 360 - Smart Elderly Care & Monitoring System")
        print("=" * 60)
        print(f" Web Server running at: http://localhost:{PORT}")
        print(f" ESP32 Sensor Ingestion Endpoint: http://localhost:{PORT}/api/sensor")
        print(" Press Ctrl+C to terminate.")
        print("=" * 60)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server.")

if __name__ == '__main__':
    run_server()
