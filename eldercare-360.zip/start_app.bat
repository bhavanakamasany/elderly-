@echo off
title ElderCare 360 - Smart Elderly Care System
echo ========================================================
echo  Starting ElderCare 360 - Smart Elderly Care System
echo ========================================================
echo.
cd /d "%~dp0"
start "" http://localhost:8000
python server.py
pause
