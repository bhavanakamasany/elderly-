/**
 * ElderCare 360 - Hardware Integration (ESP32 & MPU-6050 IMU)
 * Real-time 6-DoF Sensor Streaming, Dynamic Waveform Graphs, Calibration,
 * and Ready-to-Flash Arduino / ESP32 C++ Firmware Sketch.
 */

class HardwareIntegration {
  constructor() {
    this.streamCanvas = null;
    this.streamCtx = null;
    this.telemetryHistory = {
      ax: [],
      ay: [],
      az: []
    };
    for (let i = 0; i < 60; i++) {
      this.telemetryHistory.ax.push(0.05);
      this.telemetryHistory.ay.push(-0.08);
      this.telemetryHistory.az.push(1.0);
    }
    this.streamInterval = null;
    this.init();
    this.bindEvents();
  }

  init() {
    this.streamCanvas = document.getElementById('hardware-telemetry-canvas');
    if (this.streamCanvas) {
      this.streamCtx = this.streamCanvas.getContext('2d');
      this.startTelemetryLoop();
    }
  }

  bindEvents() {
    const calibrateBtn = document.getElementById('btn-calibrate-sensor');
    if (calibrateBtn) {
      calibrateBtn.addEventListener('click', () => this.calibrateSensor());
    }

    const toggleHwBtn = document.getElementById('btn-toggle-hardware-status');
    if (toggleHwBtn) {
      toggleHwBtn.addEventListener('click', () => this.toggleHardwareConnection());
    }

    const copyCodeBtn = document.getElementById('btn-copy-arduino-code');
    if (copyCodeBtn) {
      copyCodeBtn.addEventListener('click', () => this.copyArduinoSketch());
    }
  }

  startTelemetryLoop() {
    if (this.streamInterval) clearInterval(this.streamInterval);

    this.streamInterval = setInterval(() => {
      this.simulateSensorTick();
      this.drawTelemetry();
      this.updateOrientationVisualizer();
    }, 100); // 10 Hz refresh
  }

  simulateSensorTick() {
    const s = window.store.state.sensor;
    if (s.status.includes('Offline')) return;

    // Small natural micro-movements
    const noise = () => (Math.random() - 0.5) * 0.04;
    s.ax = Number((0.05 + noise()).toFixed(3));
    s.ay = Number((-0.06 + noise()).toFixed(3));

    // If fall countdown is not active, normal 1G gravity
    if (window.store.state.fallDetection.state !== 'COUNTDOWN') {
      s.az = Number((0.99 + noise()).toFixed(3));
      s.pitch = Number((2.1 + (Math.random() - 0.5) * 1.5).toFixed(1));
      s.roll = Number((-1.2 + (Math.random() - 0.5) * 1.2).toFixed(1));
    }

    s.gForceTotal = Number(Math.sqrt(s.ax * s.ax + s.ay * s.ay + s.az * s.az).toFixed(2));

    this.telemetryHistory.ax.push(s.ax);
    this.telemetryHistory.ay.push(s.ay);
    this.telemetryHistory.az.push(s.az);

    if (this.telemetryHistory.ax.length > 60) {
      this.telemetryHistory.ax.shift();
      this.telemetryHistory.ay.shift();
      this.telemetryHistory.az.shift();
    }
  }

  drawTelemetry() {
    if (!this.streamCanvas || !this.streamCtx) return;
    const ctx = this.streamCtx;
    const w = this.streamCanvas.width;
    const h = this.streamCanvas.height;
    const midY = h / 2;

    ctx.clearRect(0, 0, w, h);

    // Draw baseline
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, midY);
    ctx.lineTo(w, midY);
    ctx.stroke();

    const drawAxis = (data, color, scale = 35) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      const step = w / (data.length - 1);
      data.forEach((val, i) => {
        const y = midY - (val * scale);
        const x = i * step;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    };

    drawAxis(this.telemetryHistory.ax, '#ef4444'); // X = Red
    drawAxis(this.telemetryHistory.ay, '#10b981'); // Y = Green
    drawAxis(this.telemetryHistory.az, '#38bdf8'); // Z = Blue
  }

  updateOrientationVisualizer() {
    const s = window.store.state.sensor;
    const imuBox = document.getElementById('imu-visual-box');
    if (imuBox) {
      imuBox.style.transform = `rotateX(${s.pitch}deg) rotateZ(${s.roll}deg)`;
    }

    // Update real-time numerical readings
    const elAx = document.getElementById('hw-readout-ax');
    const elAy = document.getElementById('hw-readout-ay');
    const elAz = document.getElementById('hw-readout-az');
    const elG = document.getElementById('hw-readout-gtotal');
    const elPitch = document.getElementById('hw-readout-pitch');
    const elRoll = document.getElementById('hw-readout-roll');

    if (elAx) elAx.textContent = s.ax + ' g';
    if (elAy) elAy.textContent = s.ay + ' g';
    if (elAz) elAz.textContent = s.az + ' g';
    if (elG) elG.textContent = s.gForceTotal + ' g';
    if (elPitch) elPitch.textContent = s.pitch + '°';
    if (elRoll) elRoll.textContent = s.roll + '°';
  }

  calibrateSensor() {
    window.audioService.playTone(880, 'sine', 0.2, 0.15);
    const s = window.store.state.sensor;
    s.pitch = 0.0;
    s.roll = 0.0;
    s.ax = 0.00;
    s.ay = 0.00;
    s.az = 1.00;
    s.gForceTotal = 1.00;
    window.store.addNotification('Sensor Calibrated', 'MPU-6050 Zero-G and tilt offsets calibrated successfully.', 'info', '📐');
    window.store.saveState();
    window.showToast('Sensor offsets calibrated to 0.0° Level!', 'success');
  }

  toggleHardwareConnection() {
    const s = window.store.state.sensor;
    if (s.status.includes('Connected')) {
      s.status = 'Offline (Disconnected)';
      window.showToast('ESP32 status set to Offline', 'warning');
      window.store.addNotification('Hardware Offline', 'ESP32 Wi-Fi heartbeat timeout.', 'warning', '⚠️');
    } else {
      s.status = 'Connected (Simulated)';
      window.showToast('ESP32 Reconnected successfully!', 'success');
      window.store.addNotification('Hardware Connected', 'ESP32 heartbeat re-established at 50Hz.', 'success', '🔌');
    }
    window.store.saveState();
    this.render();
  }

  copyArduinoSketch() {
    const codeEl = document.getElementById('arduino-sketch-code');
    if (codeEl) {
      navigator.clipboard.writeText(codeEl.innerText).then(() => {
        window.showToast('Arduino sketch copied to clipboard!', 'success');
      }).catch(() => {
        window.showToast('Copied code to clipboard', 'info');
      });
    }
  }

  render() {
    const s = window.store.state.sensor;
    if (!s) return;

    const statusBadge = document.getElementById('hw-connection-badge');
    if (statusBadge) {
      const isOnline = s.status.includes('Connected');
      statusBadge.textContent = s.status;
      statusBadge.style.background = isOnline ? '#d1fae5' : '#fee2e2';
      statusBadge.style.color = isOnline ? '#065f46' : '#991b1b';
    }

    const batteryEl = document.getElementById('hw-battery-val');
    if (batteryEl) batteryEl.textContent = s.battery + '%';

    const rssiEl = document.getElementById('hw-rssi-val');
    if (rssiEl) rssiEl.textContent = s.rssi + ' dBm';
  }
}

// Global instance
window.hardwareIntegration = new HardwareIntegration();
