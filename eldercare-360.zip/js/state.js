/**
 * ElderCare 360 - Central Application State & Persistence Store
 */

const STORAGE_KEY = 'eldercare_360_state_v1';

const DEFAULT_STATE = {
  demoMode: true,
  senior: {
    name: 'Arthur Pendelton',
    age: 74,
    gender: 'Male',
    bloodGroup: 'O+',
    room: 'Room 204 - Assisted Living',
    weight: '68 kg',
    height: '172 cm',
    doctor: 'Dr. Sarah Adams',
    caregiver: 'Michael Pendelton (Son)'
  },
  fallDetection: {
    state: 'NORMAL', // NORMAL | IMPACT_DETECTED | COUNTDOWN | SOS_TRIGGERED | CANCELLED
    sensitivity: 'Medium (3.2g threshold)',
    countdownSeconds: 15,
    lastFallTimestamp: null,
    history: [
      {
        id: 'fall-001',
        time: 'Yesterday at 4:15 PM',
        type: 'Bedside Slip (Minor Impact)',
        gForce: '3.4g',
        actionTaken: 'Cancelled by Arthur (False Alarm)',
        status: 'Resolved'
      }
    ]
  },
  sensor: {
    device: 'ESP32 NodeMCU + MPU-6050',
    status: 'Connected (Simulated)',
    battery: 88,
    rssi: -58,
    samplingRate: '50 Hz',
    gForceTotal: 1.02,
    pitch: 2.1,
    roll: -1.4,
    ax: 0.05,
    ay: -0.08,
    az: 1.01,
    gx: 0.2,
    gy: -0.1,
    gz: 0.0
  },
  vitals: {
    heartRate: 74,
    heartRateStatus: 'Normal',
    bloodPressureSystolic: 122,
    bloodPressureDiastolic: 78,
    temperatureC: 36.7,
    temperatureF: 98.1,
    spO2: 98,
    glucose: 104,
    history: [
      { time: '08:00 AM', hr: 72, bp: '120/78', temp: 36.6, spo2: 98 },
      { time: '11:30 AM', hr: 76, bp: '124/80', temp: 36.7, spo2: 98 },
      { time: '02:00 PM', hr: 78, bp: '125/81', temp: 36.8, spo2: 97 },
      { time: '05:30 PM', hr: 74, bp: '122/78', temp: 36.7, spo2: 98 }
    ]
  },
  steps: {
    current: 4320,
    goal: 6000,
    distanceKm: 2.9,
    caloriesBurned: 184,
    activeMinutes: 38,
    weekly: [
      { day: 'Mon', steps: 5890 },
      { day: 'Tue', steps: 6120 },
      { day: 'Wed', steps: 4850 },
      { day: 'Thu', steps: 5400 },
      { day: 'Fri', steps: 6300 },
      { day: 'Sat', steps: 3950 },
      { day: 'Sun', steps: 4320 }
    ]
  },
  medicines: [
    {
      id: 'med-1',
      name: 'Amlodipine (Norvasc)',
      dosage: '5 mg - 1 Tablet',
      timeSlot: 'Morning (08:00 AM)',
      time: '08:00',
      instruction: 'After breakfast for Blood Pressure',
      icon: '💊',
      color: 'blue',
      status: 'taken',
      refillRemaining: 18
    },
    {
      id: 'med-2',
      name: 'Metformin HCl',
      dosage: '500 mg - 1 Tablet',
      timeSlot: 'Morning (08:30 AM)',
      time: '08:30',
      instruction: 'With meal for Blood Sugar',
      icon: '🩺',
      color: 'teal',
      status: 'taken',
      refillRemaining: 24
    },
    {
      id: 'med-3',
      name: 'Atorvastatin',
      dosage: '10 mg - 1 Tablet',
      timeSlot: 'Evening (07:00 PM)',
      time: '19:00',
      instruction: 'Before dinner for Cholesterol',
      icon: '💊',
      color: 'purple',
      status: 'pending',
      refillRemaining: 12
    },
    {
      id: 'med-4',
      name: 'Calcium + Vitamin D3',
      dosage: '600 mg + 400 IU',
      timeSlot: 'Night (09:00 PM)',
      time: '21:00',
      instruction: 'Before sleep for Bone Support',
      icon: '✨',
      color: 'amber',
      status: 'pending',
      refillRemaining: 30
    }
  ],
  emergencyContacts: [
    {
      id: 'cnt-1',
      name: 'Michael Pendelton',
      relationship: 'Son (Primary Caregiver)',
      phone: '+1 (555) 234-5678',
      email: 'michael.p@email.com',
      avatar: '👨‍💼',
      notifyOnFall: true,
      notifyOnMedMissed: true
    },
    {
      id: 'cnt-2',
      name: 'Emily Davis (Pendelton)',
      relationship: 'Daughter',
      phone: '+1 (555) 876-5432',
      email: 'emily.davis@email.com',
      avatar: '👩‍💼',
      notifyOnFall: true,
      notifyOnMedMissed: false
    },
    {
      id: 'cnt-3',
      name: 'Dr. Sarah Adams',
      relationship: 'Primary Geriatrician',
      phone: '+1 (555) 432-1000',
      email: 'dr.adams@stjudehealth.org',
      avatar: '🩺',
      notifyOnFall: true,
      notifyOnMedMissed: false
    },
    {
      id: 'cnt-4',
      name: 'St. Jude Emergency Dispatch',
      relationship: 'Local EMS / Ambulance',
      phone: '911 / (555) 000-HELP',
      email: 'ems@stjude.org',
      avatar: '🚑',
      notifyOnFall: true,
      notifyOnMedMissed: false
    }
  ],
  routine: {
    waterGlassesCurrent: 5,
    waterGlassesTarget: 8,
    sleep: {
      durationHours: 7.4,
      score: 84,
      bedTime: '10:45 PM',
      wakeTime: '06:10 AM',
      deepSleepHours: 1.8,
      lightSleepHours: 4.2,
      remSleepHours: 1.4,
      awakeMins: 22
    },
    exercises: [
      { id: 'ex-1', title: 'Gentle Joint Stretches', duration: '10 mins', done: true },
      { id: 'ex-2', title: 'Living Room Walkway Lap', duration: '15 mins', done: true },
      { id: 'ex-3', title: 'Seated Resistance Band Flex', duration: '10 mins', done: false }
    ],
    appointments: [
      {
        id: 'apt-1',
        doctor: 'Dr. Sarah Adams (Cardiology Check)',
        clinic: 'Suite 302, St. Jude Medical Arts',
        date: 'Thursday, Nov 14, 2026',
        time: '10:30 AM',
        notes: 'Bring last 7-day BP log sheet'
      },
      {
        id: 'apt-2',
        doctor: 'Dr. Harold Chen (Optometry)',
        clinic: 'Valley Vision Care Center',
        date: 'Tuesday, Nov 26, 2026',
        time: '02:00 PM',
        notes: 'Annual diabetic retinopathy screening'
      }
    ]
  },
  notifications: [
    {
      id: 'notif-1',
      title: 'Morning Medication Logged',
      message: 'Arthur confirmed taking Amlodipine 5mg on time.',
      time: '08:05 AM',
      type: 'success',
      icon: '💊'
    },
    {
      id: 'notif-2',
      title: 'Hydration Milestone',
      message: 'Reached 5/8 glasses of water for today. Well done!',
      time: '01:30 PM',
      type: 'info',
      icon: '💧'
    },
    {
      id: 'notif-3',
      title: 'ESP32 Sensor Calibrated',
      message: 'Zero-G baseline offset calibrated successfully.',
      time: '10:00 AM',
      type: 'info',
      icon: '🔌'
    }
  ],
  caregiverNotes: [
    {
      id: 'note-1',
      author: 'Michael (Son)',
      time: '12:45 PM',
      text: 'Dropped off fresh fruit. Arthur was smiling and feeling active!'
    }
  ]
};

class StateManager {
  constructor() {
    this.listeners = [];
    this.state = this.loadState();
  }

  loadState() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return { ...DEFAULT_STATE, ...JSON.parse(stored) };
      }
    } catch (e) {
      console.warn('Failed to load state from localStorage', e);
    }
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }

  saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
      this.notify();
    } catch (e) {
      console.warn('Failed to save state', e);
    }
  }

  resetToDefault() {
    this.state = JSON.parse(JSON.stringify(DEFAULT_STATE));
    this.saveState();
  }

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  notify() {
    this.listeners.forEach(fn => {
      try {
        fn(this.state);
      } catch (err) {
        console.error('State subscriber error', err);
      }
    });
  }

  addNotification(title, message, type = 'info', icon = '🔔') {
    const newNotif = {
      id: 'notif-' + Date.now(),
      title,
      message,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type,
      icon
    };
    this.state.notifications.unshift(newNotif);
    if (this.state.notifications.length > 50) {
      this.state.notifications.pop();
    }
    this.saveState();
  }
}

// Global store
window.store = new StateManager();
