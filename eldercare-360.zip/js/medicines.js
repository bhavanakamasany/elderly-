/**
 * ElderCare 360 - Medicine Reminders & Tablet Compliance Manager
 */

class MedicineManager {
  constructor() {
    this.filter = 'all'; // all | morning | evening | night | pending
    this.bindEvents();
  }

  bindEvents() {
    // Add Medicine Form submission
    const form = document.getElementById('add-med-form');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleAddMedicine();
      });
    }

    // Filter pill tabs
    const filterBtns = document.querySelectorAll('.med-filter-btn');
    filterBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        filterBtns.forEach(b => b.classList.remove('active'));
        e.currentTarget.classList.add('active');
        this.filter = e.currentTarget.getAttribute('data-filter') || 'all';
        this.render();
      });
    });
  }

  handleAddMedicine() {
    const nameInput = document.getElementById('med-name-input');
    const doseInput = document.getElementById('med-dosage-input');
    const timeInput = document.getElementById('med-time-input');
    const slotInput = document.getElementById('med-slot-input');
    const instrInput = document.getElementById('med-instruction-input');
    const refillInput = document.getElementById('med-refill-input');

    if (!nameInput || !nameInput.value.trim()) {
      window.showToast('Please enter a medicine name', 'warning');
      return;
    }

    const newMed = {
      id: 'med-' + Date.now(),
      name: nameInput.value.trim(),
      dosage: doseInput ? doseInput.value.trim() : '1 Tablet',
      time: timeInput ? timeInput.value : '08:00',
      timeSlot: slotInput ? slotInput.value : 'Morning',
      instruction: instrInput ? instrInput.value.trim() : 'Take with water',
      icon: '💊',
      color: 'blue',
      status: 'pending',
      refillRemaining: refillInput ? parseInt(refillInput.value, 10) || 30 : 30
    };

    window.store.state.medicines.push(newMed);
    window.store.addNotification('New Medication Added', `Added ${newMed.name} (${newMed.dosage}) scheduled for ${newMed.timeSlot}.`, 'info', '💊');
    window.store.saveState();

    // Close modal
    window.closeModal('add-med-modal');
    form.reset();

    window.showToast(`Medication "${newMed.name}" added successfully!`, 'success');
    window.audioService.playChime();
    this.render();
  }

  markStatus(medId, newStatus) {
    const med = window.store.state.medicines.find(m => m.id === medId);
    if (!med) return;

    med.status = newStatus;
    if (newStatus === 'taken') {
      window.audioService.playSuccess();
      window.audioService.speak(`Good job! Marked ${med.name} as taken.`);
      window.store.addNotification('Medication Taken', `Arthur took ${med.name} (${med.dosage})`, 'success', '✅');
      window.showToast(`Great! Marked ${med.name} as Taken.`, 'success');
    } else if (newStatus === 'missed') {
      window.store.addNotification('Medication Missed', `Dose of ${med.name} was marked as missed. Caregiver notified.`, 'warning', '⚠️');
      window.showToast(`Marked ${med.name} as Missed.`, 'warning');
    } else if (newStatus === 'snooze') {
      med.status = 'pending';
      window.showToast(`Reminder for ${med.name} snoozed for 15 minutes.`, 'info');
    }

    window.store.saveState();
    this.render();
  }

  triggerPillReminder(medId) {
    const med = window.store.state.medicines.find(m => m.id === medId) || window.store.state.medicines[0];
    if (!med) return;

    window.audioService.playChime();
    window.audioService.speak(`Time for medication! Please take ${med.name}, ${med.dosage}.`);

    window.showToast(`⏰ Medication Reminder: It's time to take ${med.name} (${med.dosage})!`, 'warning', 6000);
    window.store.addNotification('Medication Reminder', `Time to take ${med.name} (${med.dosage}) - ${med.instruction}`, 'warning', '⏰');
  }

  render() {
    const container = document.getElementById('medications-list-container');
    const dashboardMedsContainer = document.getElementById('dashboard-meds-summary');
    if (!container && !dashboardMedsContainer) return;

    const meds = window.store.state.medicines || [];

    // Filter
    let filtered = meds;
    if (this.filter === 'pending') {
      filtered = meds.filter(m => m.status === 'pending');
    } else if (this.filter === 'taken') {
      filtered = meds.filter(m => m.status === 'taken');
    } else if (this.filter !== 'all') {
      filtered = meds.filter(m => m.timeSlot.toLowerCase().includes(this.filter.toLowerCase()));
    }

    // Calculate adherence stats
    const totalCount = meds.length;
    const takenCount = meds.filter(m => m.status === 'taken').length;
    const pendingCount = meds.filter(m => m.status === 'pending').length;
    const adherenceRate = totalCount > 0 ? Math.round((takenCount / totalCount) * 100) : 100;

    // Update Adherence Badges
    const adherenceEl = document.getElementById('med-adherence-rate');
    if (adherenceEl) adherenceEl.textContent = adherenceRate + '%';

    const pendingBadge = document.getElementById('sidebar-med-badge');
    if (pendingBadge) {
      pendingBadge.textContent = pendingCount;
      pendingBadge.style.display = pendingCount > 0 ? 'inline-block' : 'none';
    }

    // Render Full List
    if (container) {
      if (filtered.length === 0) {
        container.innerHTML = `
          <div style="text-align:center; padding: 2.5rem 1rem; color: var(--text-muted);">
            <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">🎉</div>
            <p style="font-weight: 600; font-size: 1.05rem; color: var(--text-primary);">No medicines found for this filter</p>
            <p style="font-size: 0.85rem;">All scheduled tablets are accounted for!</p>
          </div>
        `;
      } else {
        container.innerHTML = filtered.map(med => {
          const isTaken = med.status === 'taken';
          const isMissed = med.status === 'missed';
          return `
            <div class="med-card ${isTaken ? 'status-taken' : ''} ${isMissed ? 'status-missed' : ''}">
              <div class="med-left">
                <div class="med-icon-pill icon-${med.color || 'blue'}">
                  ${med.icon || '💊'}
                </div>
                <div class="med-details">
                  <h4>${med.name}</h4>
                  <p><strong>${med.dosage}</strong> • ${med.instruction}</p>
                  <div class="med-meta">
                    <span class="med-badge" style="background: var(--bg-surface); color: var(--text-secondary);">⏰ ${med.timeSlot}</span>
                    ${med.refillRemaining <= 15 ? `<span class="med-badge" style="background:#fef3c7; color:#b45309;">⚠️ Refill: ${med.refillRemaining} left</span>` : ''}
                    <span class="med-badge" style="background: ${isTaken ? '#d1fae5' : isMissed ? '#fee2e2' : '#e0f2fe'}; color: ${isTaken ? '#065f46' : isMissed ? '#991b1b' : '#0369a1'};">
                      ${isTaken ? '✓ Taken' : isMissed ? '✕ Missed' : '● Scheduled'}
                    </span>
                  </div>
                </div>
              </div>
              <div class="med-actions">
                ${!isTaken ? `
                  <button class="btn btn-primary btn-sm" onclick="window.medicineManager.markStatus('${med.id}', 'taken')" title="Mark as Taken">
                    ✓ Take Now
                  </button>
                  <button class="btn btn-outline btn-sm" onclick="window.medicineManager.markStatus('${med.id}', 'snooze')" title="Snooze 15m">
                    💤 Snooze
                  </button>
                  <button class="btn btn-outline btn-sm" style="color:var(--danger);" onclick="window.medicineManager.markStatus('${med.id}', 'missed')" title="Mark Missed">
                    ✕
                  </button>
                ` : `
                  <button class="btn btn-outline btn-sm" onclick="window.medicineManager.markStatus('${med.id}', 'pending')" title="Undo">
                    Undo
                  </button>
                `}
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // Render Compact Dashboard Summary
    if (dashboardMedsContainer) {
      dashboardMedsContainer.innerHTML = meds.slice(0, 3).map(med => `
        <div style="display:flex; align-items:center; justify-content:space-between; padding:0.65rem 0; border-bottom:1px solid var(--border-light);">
          <div>
            <div style="font-weight:600; font-size:0.9rem;">${med.name}</div>
            <div style="font-size:0.75rem; color:var(--text-muted);">${med.dosage} • ${med.timeSlot}</div>
          </div>
          <div>
            ${med.status === 'taken' 
              ? `<span style="font-size:0.75rem; font-weight:700; color:var(--success); background:var(--success-light); padding:0.2rem 0.55rem; border-radius:9999px;">✓ Taken</span>`
              : `<button class="btn btn-primary btn-sm" onclick="window.medicineManager.markStatus('${med.id}', 'taken')">Take</button>`
            }
          </div>
        </div>
      `).join('');
    }
  }
}

// Global instance
window.medicineManager = new MedicineManager();
