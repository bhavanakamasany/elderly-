/**
 * ElderCare 360 - Daily Routine, Hydration, Sleep & Appointments Module
 */

class RoutineManager {
  constructor() {
    this.bindEvents();
  }

  bindEvents() {
    // Add Appointment Form
    const aptForm = document.getElementById('add-appointment-form');
    if (aptForm) {
      aptForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleAddAppointment();
      });
    }
  }

  toggleWaterGlass(glassIndex) {
    const r = window.store.state.routine;
    if (glassIndex < r.waterGlassesCurrent) {
      // Unfill down to this glass
      r.waterGlassesCurrent = glassIndex;
    } else {
      // Fill up to this glass
      r.waterGlassesCurrent = glassIndex + 1;
      window.audioService.playTone(720, 'sine', 0.15, 0.12);

      if (r.waterGlassesCurrent >= r.waterGlassesTarget) {
        window.audioService.playSuccess();
        window.audioService.speak('Awesome! You reached your daily hydration goal of 8 glasses of water.');
        window.store.addNotification('Hydration Goal Reached! 💧', 'Arthur drank 8 glasses of water today. Excellent kidney health!', 'success', '💧');
      }
    }
    window.store.saveState();
    this.render();
  }

  toggleExercise(exId) {
    const ex = window.store.state.routine.exercises.find(e => e.id === exId);
    if (!ex) return;

    ex.done = !ex.done;
    if (ex.done) {
      window.audioService.playSuccess();
      window.audioService.speak(`Well done Arthur! Completed ${ex.title}.`);
      window.store.addNotification('Exercise Completed 🏃', `Arthur finished ${ex.title} (${ex.duration}).`, 'success', '🏃');
      window.showToast(`Great job! Completed ${ex.title}`, 'success');
    }
    window.store.saveState();
    this.render();
  }

  handleAddAppointment() {
    const docInput = document.getElementById('input-apt-doc');
    const clinicInput = document.getElementById('input-apt-clinic');
    const dateInput = document.getElementById('input-apt-date');
    const timeInput = document.getElementById('input-apt-time');
    const notesInput = document.getElementById('input-apt-notes');

    if (!docInput || !docInput.value.trim()) {
      window.showToast('Please enter doctor or specialty', 'warning');
      return;
    }

    const newApt = {
      id: 'apt-' + Date.now(),
      doctor: docInput.value.trim(),
      clinic: clinicInput ? clinicInput.value.trim() : 'Medical Clinic',
      date: dateInput ? dateInput.value : 'Upcoming',
      time: timeInput ? timeInput.value : '10:00 AM',
      notes: notesInput ? notesInput.value.trim() : 'Routine check'
    };

    window.store.state.routine.appointments.push(newApt);
    window.store.addNotification('Doctor Appointment Scheduled', `Scheduled with ${newApt.doctor} on ${newApt.date} at ${newApt.time}.`, 'info', '📅');
    window.store.saveState();

    window.closeModal('add-appointment-modal');
    window.showToast('Doctor appointment added!', 'success');
    this.render();
  }

  deleteAppointment(id) {
    window.store.state.routine.appointments = window.store.state.routine.appointments.filter(a => a.id !== id);
    window.store.saveState();
    window.showToast('Appointment removed', 'info');
    this.render();
  }

  render() {
    const r = window.store.state.routine;
    if (!r) return;

    // Water Glasses Render
    const waterRow = document.getElementById('water-glasses-row');
    if (waterRow) {
      let glassesHtml = '';
      for (let i = 0; i < r.waterGlassesTarget; i++) {
        const isFilled = i < r.waterGlassesCurrent;
        glassesHtml += `
          <button class="water-glass-btn ${isFilled ? 'filled' : ''}" onclick="window.routineManager.toggleWaterGlass(${i})" title="${isFilled ? 'Filled' : 'Click to drink glass ' + (i+1)}">
            <span style="font-size: 1.15rem;">${isFilled ? '💧' : '🥛'}</span>
            <span>${(i + 1) * 250}ml</span>
          </button>
        `;
      }
      waterRow.innerHTML = glassesHtml;
    }

    const waterValEls = document.querySelectorAll('.water-current-val');
    waterValEls.forEach(el => el.textContent = `${r.waterGlassesCurrent} / ${r.waterGlassesTarget}`);

    const waterMlsEls = document.querySelectorAll('.water-ml-val');
    waterMlsEls.forEach(el => el.textContent = `${r.waterGlassesCurrent * 250} ml`);

    // Sleep Render
    const sleep = r.sleep;
    if (sleep) {
      const durEls = document.querySelectorAll('.sleep-duration-val');
      durEls.forEach(el => el.textContent = `${sleep.durationHours} hrs`);

      const scoreEls = document.querySelectorAll('.sleep-score-val');
      scoreEls.forEach(el => el.textContent = `${sleep.score}/100`);

      const deepEls = document.querySelectorAll('.sleep-deep-val');
      deepEls.forEach(el => el.textContent = `${sleep.deepSleepHours}h`);

      const remEls = document.querySelectorAll('.sleep-rem-val');
      remEls.forEach(el => el.textContent = `${sleep.remSleepHours}h`);

      const lightEls = document.querySelectorAll('.sleep-light-val');
      lightEls.forEach(el => el.textContent = `${sleep.lightSleepHours}h`);
    }

    // Exercises Render
    const exContainer = document.getElementById('exercises-list-container');
    if (exContainer) {
      exContainer.innerHTML = r.exercises.map(ex => `
        <div style="display:flex; align-items:center; justify-content:space-between; padding:0.85rem 1rem; border-radius:var(--radius-md); background:var(--bg-surface); margin-bottom:0.6rem; border-left: 4px solid ${ex.done ? 'var(--success)' : 'var(--primary)'};">
          <div>
            <div style="font-weight:600; font-size:0.92rem; text-decoration: ${ex.done ? 'line-through' : 'none'}; color: ${ex.done ? 'var(--text-muted)' : 'var(--text-primary)'};">
              ${ex.title}
            </div>
            <div style="font-size:0.75rem; color:var(--text-muted);">⏱️ ${ex.duration}</div>
          </div>
          <button class="btn ${ex.done ? 'btn-outline' : 'btn-teal'} btn-sm" onclick="window.routineManager.toggleExercise('${ex.id}')">
            ${ex.done ? '✓ Completed' : 'Start'}
          </button>
        </div>
      `).join('');
    }

    // Appointments Render
    const aptContainer = document.getElementById('appointments-list-container');
    if (aptContainer) {
      if (r.appointments.length === 0) {
        aptContainer.innerHTML = '<p style="color:var(--text-muted); text-align:center; padding:1.5rem;">No upcoming appointments.</p>';
      } else {
        aptContainer.innerHTML = r.appointments.map(apt => `
          <div style="padding:1rem 1.15rem; border-radius:var(--radius-md); border:1px solid var(--border-light); background:var(--bg-card); margin-bottom:0.75rem; position:relative;">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:0.35rem;">
              <span style="font-weight:700; color:var(--primary); font-size:0.95rem;">${apt.doctor}</span>
              <span class="med-badge" style="background:#e0f2fe; color:#0369a1;">📅 ${apt.date} • ${apt.time}</span>
            </div>
            <p style="font-size:0.82rem; color:var(--text-secondary); margin-bottom:0.25rem;">📍 ${apt.clinic}</p>
            <p style="font-size:0.78rem; color:var(--text-muted); font-style:italic;">Note: ${apt.notes}</p>
            <button style="position:absolute; right:12px; bottom:12px; background:none; border:none; color:var(--danger); cursor:pointer; font-size:0.78rem;" onclick="window.routineManager.deleteAppointment('${apt.id}')">Delete</button>
          </div>
        `).join('');
      }
    }
  }
}

// Global instance
window.routineManager = new RoutineManager();
