/**
 * ElderCare 360 - Master Application Controller
 * Handles View Routing, Accessibility Features, Modals, Toasts, and State Subscriptions.
 */

// View Router
window.switchView = function(viewId) {
  // Update nav active states
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(item => {
    if (item.getAttribute('data-view') === viewId) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });

  // Update view sections
  const sections = document.querySelectorAll('.view-section');
  sections.forEach(section => {
    if (section.id === `view-${viewId}`) {
      section.classList.add('active');
    } else {
      section.classList.remove('active');
    }
  });

  // Update Topbar Title
  const titles = {
    'dashboard': { title: 'Senior Health & Safety Overview', subtitle: 'Real-time telemetry, vitals, and daily routine for Arthur Pendelton' },
    'fall-detection': { title: 'Fall Detection & Emergency Response', subtitle: 'MPU-6050 6-DoF sensor monitoring, impact triggers & safety countdown' },
    'medicines': { title: 'Medicine Reminders & Pill Compliance', subtitle: 'Daily prescription schedule, dosage tracker and adherence logs' },
    'step-tracking': { title: 'Step Tracking & Physical Activity', subtitle: 'Walking distance, calorie burn, and weekly mobility analytics' },
    'health-monitoring': { title: 'Health & Vitals Telemetry', subtitle: 'Continuous ECG rhythm, blood pressure, temperature and oxygenation' },
    'emergency-sos': { title: 'Emergency SOS & Dispatch Center', subtitle: 'Rapid escalation, caregiver broadcast and local EMS contact directory' },
    'daily-routine': { title: 'Daily Routine & Senior Wellness', subtitle: 'Hydration tracker, sleep quality metrics, and doctor appointments' },
    'caregiver': { title: 'Caregiver & Family Portal', subtitle: 'Remote senior monitoring, medication compliance, and message notes' },
    'notifications': { title: 'Notification & Alerts Hub', subtitle: 'Real-time logs of fall incidents, medication reminders, and vitals' },
    'hardware': { title: 'Hardware Integration & ESP32 / MPU6050', subtitle: 'Microcontroller connection status, live telemetry, and firmware sketches' }
  };

  const titleEl = document.getElementById('topbar-view-title');
  const subtitleEl = document.getElementById('topbar-view-subtitle');
  if (titles[viewId] && titleEl && subtitleEl) {
    titleEl.textContent = titles[viewId].title;
    subtitleEl.textContent = titles[viewId].subtitle;
  }

  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Close mobile sidebar if open
  const sidebar = document.getElementById('app-sidebar');
  if (sidebar && sidebar.classList.contains('mobile-open')) {
    sidebar.classList.remove('mobile-open');
  }
};

// Modal helpers
window.openModal = function(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
  }
};

window.closeModal = function(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
  }
};

// Toast notification system
window.showToast = function(message, type = 'info', duration = 4000) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const icons = {
    info: 'ℹ️',
    success: '✅',
    warning: '⚠️',
    danger: '🚨'
  };

  toast.innerHTML = `
    <span style="font-size:1.1rem;">${icons[type] || 'ℹ️'}</span>
    <span style="flex:1;">${message}</span>
    <button style="background:none; border:none; color:inherit; cursor:pointer; opacity:0.7;" onclick="this.parentElement.remove()">✕</button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    if (toast.parentElement) {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }
  }, duration);
};

// Document Loaded Initialization
document.addEventListener('DOMContentLoaded', () => {
  // Setup Navigation Clicks
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const view = item.getAttribute('data-view');
      if (view) {
        window.switchView(view);
      }
    });
  });

  // Mobile menu toggle
  const menuBtn = document.getElementById('btn-mobile-menu-toggle');
  const sidebar = document.getElementById('app-sidebar');
  if (menuBtn && sidebar) {
    menuBtn.addEventListener('click', () => {
      sidebar.classList.toggle('mobile-open');
    });
  }

  // Large Text Mode Toggle
  const textSizeBtn = document.getElementById('btn-toggle-large-text');
  if (textSizeBtn) {
    textSizeBtn.addEventListener('click', () => {
      document.body.classList.toggle('large-text-mode');
      const isLarge = document.body.classList.contains('large-text-mode');
      textSizeBtn.classList.toggle('active', isLarge);
      window.showToast(isLarge ? 'Senior Large Text mode enabled' : 'Normal Text mode enabled', 'info');
    });
  }

  // High Contrast Mode Toggle
  const contrastBtn = document.getElementById('btn-toggle-contrast');
  if (contrastBtn) {
    contrastBtn.addEventListener('click', () => {
      document.body.classList.toggle('high-contrast-mode');
      const isHigh = document.body.classList.contains('high-contrast-mode');
      contrastBtn.classList.toggle('active', isHigh);
      window.showToast(isHigh ? 'High Contrast mode enabled' : 'Standard theme enabled', 'info');
    });
  }

  // Sound Toggle
  const soundBtn = document.getElementById('btn-toggle-sound');
  if (soundBtn) {
    soundBtn.addEventListener('click', () => {
      window.audioService.soundEnabled = !window.audioService.soundEnabled;
      soundBtn.innerHTML = window.audioService.soundEnabled ? '🔔 Sound: ON' : '🔕 Sound: OFF';
      window.showToast(`Sound alerts ${window.audioService.soundEnabled ? 'enabled' : 'muted'}`, 'info');
    });
  }

  // Emergency SOS Header Button
  const sosBtn = document.getElementById('btn-topbar-sos');
  if (sosBtn) {
    sosBtn.addEventListener('click', () => {
      if (confirm('Are you sure you want to trigger EMERGENCY SOS? This alerts caregivers and EMS.')) {
        window.fallDetector.triggerSosConfirmed('Manual SOS Button Pressed');
      }
    });
  }

  // Notifications Page Render
  window.renderNotificationsPage = function() {
    const listEl = document.getElementById('notifications-full-list');
    if (!listEl) return;

    const notifs = window.store.state.notifications || [];
    if (notifs.length === 0) {
      listEl.innerHTML = '<p style="text-align:center; padding:2rem; color:var(--text-muted);">No notifications yet.</p>';
      return;
    }

    listEl.innerHTML = notifs.map(n => `
      <div style="display:flex; align-items:flex-start; gap:0.85rem; padding:1rem; border-radius:var(--radius-md); background:var(--bg-card); border:1px solid var(--border-light); margin-bottom:0.65rem;">
        <div style="font-size:1.4rem;">${n.icon || '🔔'}</div>
        <div style="flex:1;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <h4 style="font-size:0.95rem; font-weight:700;">${n.title}</h4>
            <span style="font-size:0.75rem; color:var(--text-muted);">${n.time}</span>
          </div>
          <p style="font-size:0.85rem; color:var(--text-secondary); margin-top:0.2rem;">${n.message}</p>
        </div>
      </div>
    `).join('');
  };

  // State Change Subscriber
  window.store.subscribe((state) => {
    // Update Dashboard Senior Vitals & Status
    const seniorStatusBadge = document.getElementById('senior-header-status');
    if (seniorStatusBadge) {
      if (state.fallDetection.state === 'COUNTDOWN') {
        seniorStatusBadge.textContent = '🚨 FALL DETECTED (COUNTDOWN)';
        seniorStatusBadge.className = 'nav-badge badge-danger';
      } else if (state.fallDetection.state === 'SOS_TRIGGERED') {
        seniorStatusBadge.textContent = '🆘 ACTIVE SOS EMERGENCY';
        seniorStatusBadge.className = 'nav-badge badge-danger';
      } else {
        seniorStatusBadge.textContent = '● All Vitals Stable';
        seniorStatusBadge.className = 'nav-badge badge-teal';
      }
    }

    // Refresh sub-views
    if (window.medicineManager) window.medicineManager.render();
    if (window.stepTracker) window.stepTracker.render();
    if (window.vitalsMonitor) window.vitalsMonitor.render();
    if (window.routineManager) window.routineManager.render();
    if (window.caregiverPortal) window.caregiverPortal.render();
    if (window.hardwareIntegration) window.hardwareIntegration.render();
    if (window.renderNotificationsPage) window.renderNotificationsPage();
  });

  // Initial render of all views
  window.medicineManager.render();
  window.stepTracker.render();
  window.vitalsMonitor.render();
  window.routineManager.render();
  window.caregiverPortal.render();
  window.hardwareIntegration.render();
  window.renderNotificationsPage();
});
