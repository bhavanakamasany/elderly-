/**
 * ElderCare 360 - Health & Vitals Monitoring Module
 * Features Live ECG Canvas Waveform, Blood Pressure & Temp Tracking, and Vitals History Logs
 */

class VitalsMonitor {
  constructor() {
    this.ecgRunning = false;
    this.ecgOffset = 0;
    this.animationFrameId = null;
    this.initECG();
    this.bindEvents();
  }

  initECG() {
    this.canvas = document.getElementById('ecg-live-canvas');
    if (this.canvas) {
      this.ctx = this.canvas.getContext('2d');
      this.startECGAnimation();
    }
  }

  bindEvents() {
    const logBtn = document.getElementById('btn-log-vitals-modal');
    if (logBtn) {
      logBtn.addEventListener('click', () => window.openModal('log-vitals-modal'));
    }

    const form = document.getElementById('log-vitals-form');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleManualLog();
      });
    }
  }

  handleManualLog() {
    const hr = Number(document.getElementById('input-vital-hr').value);
    const sys = Number(document.getElementById('input-vital-sys').value);
    const dia = Number(document.getElementById('input-vital-dia').value);
    const temp = Number(document.getElementById('input-vital-temp').value);
    const spo2 = Number(document.getElementById('input-vital-spo2').value);

    const v = window.store.state.vitals;
    if (hr) v.heartRate = hr;
    if (sys && dia) {
      v.bloodPressureSystolic = sys;
      v.bloodPressureDiastolic = dia;
    }
    if (temp) {
      v.temperatureC = temp;
      v.temperatureF = Number(((temp * 9 / 5) + 32).toFixed(1));
    }
    if (spo2) v.spO2 = spo2;

    const newEntry = {
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      hr: v.heartRate,
      bp: `${v.bloodPressureSystolic}/${v.bloodPressureDiastolic}`,
      temp: v.temperatureC,
      spo2: v.spO2
    };

    v.history.unshift(newEntry);
    if (v.history.length > 20) v.history.pop();

    window.store.addNotification('New Vitals Logged', `BP: ${newEntry.bp} mmHg, HR: ${newEntry.hr} BPM, Temp: ${newEntry.temp}°C`, 'info', '🩺');
    window.store.saveState();
    window.closeModal('log-vitals-modal');
    window.showToast('Vitals recorded successfully!', 'success');
    this.render();
  }

  startECGAnimation() {
    if (this.ecgRunning) return;
    this.ecgRunning = true;

    const renderFrame = () => {
      this.drawECGFrame();
      this.animationFrameId = requestAnimationFrame(renderFrame);
    };
    renderFrame();
  }

  drawECGFrame() {
    if (!this.canvas || !this.ctx) return;
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    const midY = h / 2;

    // Fade trail
    ctx.fillStyle = 'rgba(9, 19, 31, 0.25)';
    ctx.fillRect(0, 0, w, h);

    // Heart rate influences speed
    const hr = window.store.state.vitals ? window.store.state.vitals.heartRate : 74;
    const speed = (hr / 60) * 2.2;
    this.ecgOffset = (this.ecgOffset + speed) % 180;

    // Medical ECG Waveform Generator
    // P-wave, Q dip, R spike, S dip, T-wave
    const getECGValue = (phase) => {
      // phase between 0 and 180
      if (phase >= 20 && phase <= 35) {
        // P wave (atrial depolarization)
        return Math.sin(((phase - 20) / 15) * Math.PI) * 7;
      }
      if (phase >= 45 && phase <= 50) {
        // Q wave (small downward deflection)
        return -5;
      }
      if (phase > 50 && phase <= 60) {
        // R wave (sharp ventricular spike)
        return ((phase - 50) / 10) * 36;
      }
      if (phase > 60 && phase <= 70) {
        // S wave (sharp return down past baseline)
        return 36 - ((phase - 60) / 10) * 46;
      }
      if (phase > 70 && phase <= 78) {
        // return from S wave to baseline
        return -10 + ((phase - 70) / 8) * 10;
      }
      if (phase >= 95 && phase <= 125) {
        // T wave (ventricular repolarization)
        return Math.sin(((phase - 95) / 30) * Math.PI) * 12;
      }
      return (Math.random() - 0.5) * 1.5; // slight baseline analog noise
    };

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2.2;
    ctx.shadowBlur = 8;
    ctx.shadowColor = '#38bdf8';
    ctx.beginPath();

    for (let x = 0; x < w; x += 3) {
      const phase = (x + this.ecgOffset) % 180;
      const y = midY - getECGValue(phase);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;
  }

  render() {
    const v = window.store.state.vitals;
    if (!v) return;

    // Heart Rate
    const hrValEls = document.querySelectorAll('.vitals-hr-val');
    hrValEls.forEach(el => el.textContent = v.heartRate);

    // Blood Pressure
    const bpValEls = document.querySelectorAll('.vitals-bp-val');
    bpValEls.forEach(el => el.textContent = `${v.bloodPressureSystolic}/${v.bloodPressureDiastolic}`);

    // Temperature
    const tempValEls = document.querySelectorAll('.vitals-temp-val');
    tempValEls.forEach(el => el.textContent = `${v.temperatureC}°C`);

    // SpO2
    const spo2ValEls = document.querySelectorAll('.vitals-spo2-val');
    spo2ValEls.forEach(el => el.textContent = `${v.spO2}%`);

    // Blood Glucose
    const gluValEls = document.querySelectorAll('.vitals-glucose-val');
    gluValEls.forEach(el => el.textContent = `${v.glucose} mg/dL`);

    // Render Vitals History Table
    const tableBody = document.getElementById('vitals-history-table-body');
    if (tableBody) {
      tableBody.innerHTML = (v.history || []).map(row => `
        <tr>
          <td><strong>${row.time}</strong></td>
          <td><span style="color:#ef4444; font-weight:700;">❤️ ${row.hr} BPM</span></td>
          <td><span style="color:#0284c7; font-weight:700;">🩺 ${row.bp} mmHg</span></td>
          <td>🌡️ ${row.temp}°C</td>
          <td>🫁 ${row.spo2}%</td>
          <td><span class="med-badge" style="background:#d1fae5; color:#065f46;">Optimal</span></td>
        </tr>
      `).join('');
    }
  }
}

// Global instance
window.vitalsMonitor = new VitalsMonitor();
