/**
 * ElderCare 360 - Fall Detection Engine & 3D Sensor Visualizer
 * Simulates MPU6050 Accelerometer + Gyroscope Fall Recognition Algorithm:
 * 1. Free-Fall Phase (|a| < 0.5g)
 * 2. High-G Impact Spike (|a| > 3.0g - 4.5g)
 * 3. Inactive Stillness / Orientation Change (Pitch/Roll > 60 deg)
 * 4. 15-Second Reversible Emergency Countdown with Audio Siren & Caregiver Escalation
 */

class FallDetector {
  constructor() {
    this.countdownTimer = null;
    this.secondsRemaining = 15;
    this.isAlertActive = false;
    this.initCanvas();
    this.bindEvents();
  }

  initCanvas() {
    // Canvas setup for real-time sensor waveform
    this.canvas = document.getElementById('fall-telemetry-canvas');
    if (this.canvas) {
      this.ctx = this.canvas.getContext('2d');
      this.waveformData = [];
      for (let i = 0; i < 50; i++) {
        this.waveformData.push(1.0); // Baseline 1.0G (Earth gravity)
      }
      this.drawWaveform();
    }
  }

  bindEvents() {
    // Cancel Fall Alert button
    const cancelBtn = document.getElementById('btn-cancel-fall-alert');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => this.cancelFallAlert('User Pressed I AM OK'));
    }

    // Force SOS Now button
    const forceSosBtn = document.getElementById('btn-force-sos-now');
    if (forceSosBtn) {
      forceSosBtn.addEventListener('click', () => this.triggerSosConfirmed('Immediate SOS Requested by User'));
    }

    // Sensitivity dropdown change
    const sensitivitySelect = document.getElementById('fall-sensitivity-select');
    if (sensitivitySelect) {
      sensitivitySelect.addEventListener('change', (e) => {
        window.store.state.fallDetection.sensitivity = e.target.value;
        window.store.saveState();
        window.showToast('Fall sensitivity updated: ' + e.target.value, 'info');
      });
    }
  }

  // Trigger simulated fall event
  triggerFallEvent(source = 'Simulated Fall Test') {
    if (this.isAlertActive) return;

    this.isAlertActive = true;
    this.secondsRemaining = 15;
    window.store.state.fallDetection.state = 'COUNTDOWN';
    window.store.state.fallDetection.lastFallTimestamp = new Date().toLocaleTimeString();

    // Simulate sensor spike
    window.store.state.sensor.gForceTotal = 3.85;
    window.store.state.sensor.pitch = 78.4; // Fallen flat
    window.store.state.sensor.roll = 45.2;
    window.store.saveState();

    this.addTelemetrySpike();

    // Show modal
    const overlay = document.getElementById('fall-alert-overlay');
    if (overlay) {
      overlay.classList.add('active');
    }

    // Audio & Voice Prompt
    window.audioService.playCountdownBeep(this.secondsRemaining);
    window.audioService.speak('Warning! Fall detected. Emergency alert will trigger in 15 seconds. Press cancel if you are safe.');

    this.updateCountdownUI();

    // Start 1-second countdown interval
    clearInterval(this.countdownTimer);
    this.countdownTimer = setInterval(() => {
      this.secondsRemaining--;
      this.updateCountdownUI();

      if (this.secondsRemaining > 0) {
        window.audioService.playCountdownBeep(this.secondsRemaining);
      } else {
        clearInterval(this.countdownTimer);
        this.triggerSosConfirmed('Countdown Expired - No Response from Senior');
      }
    }, 1000);

    window.store.addNotification('Fall Event Detected', 'MPU-6050 registered impact of 3.85G. 15s Countdown initiated.', 'danger', '🚨');
  }

  updateCountdownUI() {
    const numberEl = document.getElementById('fall-countdown-number');
    const circleEl = document.getElementById('fall-countdown-circle-progress');

    if (numberEl) {
      numberEl.textContent = this.secondsRemaining;
    }

    if (circleEl) {
      const totalOffset = 377; // 2 * PI * r (r=60)
      const fraction = this.secondsRemaining / 15;
      const offset = totalOffset * (1 - fraction);
      circleEl.style.strokeDashoffset = offset;
    }
  }

  cancelFallAlert(reason = 'Cancelled by Senior') {
    clearInterval(this.countdownTimer);
    this.isAlertActive = false;

    const overlay = document.getElementById('fall-alert-overlay');
    if (overlay) {
      overlay.classList.remove('active');
    }

    window.audioService.stopEmergencyAlarm();
    window.audioService.playSuccess();
    window.audioService.speak('Alert cancelled. Arthur is safe.');

    window.store.state.fallDetection.state = 'CANCELLED';
    window.store.state.sensor.gForceTotal = 1.0;
    window.store.state.sensor.pitch = 0.5;
    window.store.state.sensor.roll = 0.2;

    // Log to history
    window.store.state.fallDetection.history.unshift({
      id: 'fall-' + Date.now(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'Fall Impact Check (3.85G)',
      gForce: '3.85g',
      actionTaken: 'Cancelled by Senior (' + reason + ')',
      status: 'False Alarm Resolved'
    });

    window.store.addNotification('Fall Alert Cancelled', 'Senior clicked "I am OK". Caregivers notified of safe status.', 'success', '🛡️');
    window.store.saveState();

    window.showToast('Fall alert cancelled. System returned to normal monitoring.', 'success');
  }

  triggerSosConfirmed(reason = 'Emergency Confirmed') {
    clearInterval(this.countdownTimer);
    this.isAlertActive = false;

    const overlay = document.getElementById('fall-alert-overlay');
    if (overlay) {
      overlay.classList.remove('active');
    }

    window.store.state.fallDetection.state = 'SOS_TRIGGERED';

    // Start siren
    window.audioService.startEmergencyAlarm();
    window.audioService.speak('Emergency alert activated! Dispatched coordinates and SMS alerts to Michael and Dr. Adams.');

    // Log critical alert
    window.store.state.fallDetection.history.unshift({
      id: 'fall-' + Date.now(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'CONFIRMED FALL EMERGENCY',
      gForce: '3.85g (Impact)',
      actionTaken: 'Automated SOS Dispatched to Family & EMS',
      status: 'Active Alert'
    });

    window.store.addNotification('CRITICAL: SOS Dispatched', 'Emergency alert broadcasted to 4 emergency contacts with Room 204 location pin.', 'danger', '🆘');
    window.store.saveState();

    // Show SOS Confirmation Notification
    window.showToast('CRITICAL SOS DISPATCHED: Caregivers and Emergency Services alerted!', 'danger', 8000);

    // Auto-switch to Emergency SOS view so user sees the dispatched state
    if (window.switchView) {
      window.switchView('emergency-sos');
    }
  }

  addTelemetrySpike() {
    if (!this.waveformData) return;
    this.waveformData.push(0.3); // freefall dip
    this.waveformData.push(3.85); // sharp impact
    this.waveformData.push(2.1); // rebound
    this.waveformData.push(1.0); // settle
    while (this.waveformData.length > 50) {
      this.waveformData.shift();
    }
    this.drawWaveform();
  }

  drawWaveform() {
    if (!this.canvas || !this.ctx) return;
    const w = this.canvas.width;
    const h = this.canvas.height;
    const ctx = this.ctx;

    ctx.clearRect(0, 0, w, h);

    // Draw grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let y = 20; y < h; y += 25) {
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();

    // Draw baseline 1G line
    const baseLineY = h - (1.0 / 4.5) * h;
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(0, baseLineY);
    ctx.lineTo(w, baseLineY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw waveform line
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2.5;
    ctx.beginPath();

    const step = w / (this.waveformData.length - 1);
    this.waveformData.forEach((val, i) => {
      const normalized = Math.min(val / 4.5, 1.0);
      const y = h - (normalized * (h - 15) + 8);
      const x = i * step;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  }

  update3DOrientation(pitch, roll) {
    const box = document.getElementById('imu-visual-box');
    if (box) {
      box.style.transform = `rotateX(${pitch}deg) rotateZ(${roll}deg)`;
    }
  }
}

// Global instance
window.fallDetector = new FallDetector();
