/**
 * ElderCare 360 - Interactive Demo Mode Controller
 * Enables rich, interactive demonstrations of all key workflows:
 * Fall Detection, Emergency Escalation, Medicine Reminders, Vitals Fluctuation,
 * and Hardware Simulation.
 */

class DemoController {
  constructor() {
    this.bindEvents();
  }

  bindEvents() {
    // 1. Fall Event Simulation
    const btnSimFall = document.getElementById('demo-btn-fall');
    if (btnSimFall) {
      btnSimFall.addEventListener('click', () => {
        window.fallDetector.triggerFallEvent('Demo Control Bar');
      });
    }

    // 2. Pill Reminder Simulation
    const btnSimMed = document.getElementById('demo-btn-med');
    if (btnSimMed) {
      btnSimMed.addEventListener('click', () => {
        window.medicineManager.triggerPillReminder();
      });
    }

    // 3. Step Walk Simulation
    const btnSimSteps = document.getElementById('demo-btn-steps');
    if (btnSimSteps) {
      btnSimSteps.addEventListener('click', () => {
        window.stepTracker.simulateSteps(350);
      });
    }

    // 4. Vitals Fluctuation Simulation
    const btnSimVitals = document.getElementById('demo-btn-vitals');
    if (btnSimVitals) {
      btnSimVitals.addEventListener('click', () => {
        this.toggleVitalsFluctuation();
      });
    }

    // 5. Hardware Link Toggle
    const btnSimHw = document.getElementById('demo-btn-hw');
    if (btnSimHw) {
      btnSimHw.addEventListener('click', () => {
        window.hardwareIntegration.toggleHardwareConnection();
      });
    }

    // 6. Reset Demo State
    const btnReset = document.getElementById('demo-btn-reset');
    if (btnReset) {
      btnReset.addEventListener('click', () => {
        if (confirm('Reset ElderCare 360 to default initial demo data?')) {
          window.store.resetToDefault();
          window.audioService.stopEmergencyAlarm();
          window.showToast('Reset to default demo data completed.', 'info');
          window.location.reload();
        }
      });
    }
  }

  toggleVitalsFluctuation() {
    const v = window.store.state.vitals;
    if (v.heartRate > 85) {
      // Return to normal
      v.heartRate = 74;
      v.bloodPressureSystolic = 122;
      v.bloodPressureDiastolic = 78;
      v.temperatureC = 36.7;
      window.showToast('Vitals stabilized back to Normal baseline (74 BPM, 122/78 mmHg).', 'success');
      window.store.addNotification('Vitals Stabilized', 'Arthur\'s heart rate and blood pressure returned to resting baseline.', 'success', '💚');
    } else {
      // Simulate elevated
      v.heartRate = 96;
      v.bloodPressureSystolic = 138;
      v.bloodPressureDiastolic = 88;
      v.temperatureC = 37.4;
      window.audioService.playTone(480, 'triangle', 0.3, 0.18);
      window.showToast('⚠️ Simulated mild exertion: Heart Rate 96 BPM, BP 138/88 mmHg', 'warning');
      window.store.addNotification('Elevated Vitals Alert', 'Heart rate elevated to 96 BPM. Caregivers alerted to monitor.', 'warning', '⚠️');
    }
    window.store.saveState();
    window.vitalsMonitor.render();
  }
}

// Global instance
window.demoController = new DemoController();
