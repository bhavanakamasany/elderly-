/**
 * ElderCare 360 - Caregiver & Family Portal Module
 * Provides family members with remote monitoring, medication compliance tracking,
 * emergency alert audit trails, and 2-way message notes.
 */

class CaregiverPortal {
  constructor() {
    this.bindEvents();
  }

  bindEvents() {
    // Caregiver Send Note form
    const noteForm = document.getElementById('caregiver-note-form');
    if (noteForm) {
      noteForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleSendNote();
      });
    }

    // Caregiver Check-in button
    const checkinBtn = document.getElementById('btn-caregiver-checkin');
    if (checkinBtn) {
      checkinBtn.addEventListener('click', () => this.handleCheckin());
    }

    // Add Emergency Contact Form
    const contactForm = document.getElementById('add-contact-form');
    if (contactForm) {
      contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleAddContact();
      });
    }
  }

  handleCheckin() {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    window.store.addNotification('Caregiver Check-In', `Michael (Son) performed a virtual wellness check at ${time}. Arthur is in safe state.`, 'success', '👋');
    window.audioService.playSuccess();
    window.audioService.speak('Caregiver check-in recorded. Michael has checked in on you.');
    window.showToast(`Caregiver check-in logged at ${time}!`, 'success');
    this.render();
  }

  handleSendNote() {
    const input = document.getElementById('input-caregiver-note');
    if (!input || !input.value.trim()) return;

    const note = {
      id: 'note-' + Date.now(),
      author: 'Michael (Son)',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: input.value.trim()
    };

    window.store.state.caregiverNotes.unshift(note);
    window.store.addNotification('Message from Michael', `"${note.text}"`, 'info', '💬');
    window.store.saveState();

    input.value = '';

    // Play chime & voice on senior tablet
    window.audioService.playChime();
    window.audioService.speak(`Message from Michael: ${note.text}`);

    window.showToast('Note sent to Arthur\'s screen with chime!', 'success');
    this.render();
  }

  handleAddContact() {
    const nameInput = document.getElementById('input-contact-name');
    const relInput = document.getElementById('input-contact-rel');
    const phoneInput = document.getElementById('input-contact-phone');
    const emailInput = document.getElementById('input-contact-email');

    if (!nameInput || !nameInput.value.trim()) {
      window.showToast('Please enter contact name', 'warning');
      return;
    }

    const newContact = {
      id: 'cnt-' + Date.now(),
      name: nameInput.value.trim(),
      relationship: relInput ? relInput.value.trim() : 'Family Member',
      phone: phoneInput ? phoneInput.value.trim() : '+1 (555) 000-0000',
      email: emailInput ? emailInput.value.trim() : '',
      avatar: '👤',
      notifyOnFall: true,
      notifyOnMedMissed: true
    };

    window.store.state.emergencyContacts.push(newContact);
    window.store.addNotification('Emergency Contact Added', `Added ${newContact.name} (${newContact.relationship})`, 'info', '👥');
    window.store.saveState();

    window.closeModal('add-contact-modal');
    window.showToast(`Contact ${newContact.name} added!`, 'success');
    this.render();
  }

  simulateCall(contactName, phone) {
    window.audioService.playTone(440, 'sine', 0.5, 0.2);
    window.showToast(`📞 Dialing ${contactName} at ${phone}... (Simulated Emergency Call)`, 'info', 5000);
    window.store.addNotification('Emergency Call Initiated', `Connected call to ${contactName} (${phone})`, 'info', '📞');
  }

  simulateSms(contactName, phone) {
    window.audioService.playChime();
    window.showToast(`✉️ SMS Alert sent to ${contactName}: "ElderCare 360 Alert for Arthur Pendelton"`, 'success', 5000);
    window.store.addNotification('Emergency SMS Dispatched', `SMS sent to ${contactName} (${phone}) with GPS coordinates`, 'info', '✉️');
  }

  render() {
    // Caregiver Notes List
    const notesContainer = document.getElementById('caregiver-notes-list');
    if (notesContainer) {
      notesContainer.innerHTML = (window.store.state.caregiverNotes || []).map(note => `
        <div style="background:var(--bg-surface); padding:0.85rem 1rem; border-radius:var(--radius-md); margin-bottom:0.6rem; border-left:3px solid var(--primary);">
          <div style="display:flex; justify-content:space-between; font-size:0.8rem; color:var(--text-muted); margin-bottom:0.25rem;">
            <strong>${note.author}</strong>
            <span>${note.time}</span>
          </div>
          <p style="font-size:0.9rem; color:var(--text-primary);">${note.text}</p>
        </div>
      `).join('');
    }

    // Emergency Contacts List
    const contactsContainer = document.getElementById('emergency-contacts-list');
    if (contactsContainer) {
      contactsContainer.innerHTML = (window.store.state.emergencyContacts || []).map(cnt => `
        <div class="card" style="padding:1.15rem; display:flex; flex-direction:column; gap:0.65rem;">
          <div style="display:flex; align-items:center; gap:0.75rem;">
            <div style="width:42px; height:42px; border-radius:50%; background:var(--primary-light); display:flex; align-items:center; justify-content:center; font-size:1.3rem;">
              ${cnt.avatar || '👤'}
            </div>
            <div>
              <h4 style="font-size:0.95rem; font-weight:700;">${cnt.name}</h4>
              <p style="font-size:0.78rem; color:var(--text-muted);">${cnt.relationship}</p>
            </div>
          </div>
          <div style="font-size:0.85rem; color:var(--text-secondary);">
            <div>📱 <strong>${cnt.phone}</strong></div>
            ${cnt.email ? `<div>✉️ ${cnt.email}</div>` : ''}
          </div>
          <div style="display:flex; gap:0.5rem; margin-top:0.35rem;">
            <button class="btn btn-outline btn-sm" style="flex:1;" onclick="window.caregiverPortal.simulateCall('${cnt.name}', '${cnt.phone}')">
              📞 Call
            </button>
            <button class="btn btn-primary btn-sm" style="flex:1;" onclick="window.caregiverPortal.simulateSms('${cnt.name}', '${cnt.phone}')">
              ✉️ Send SMS
            </button>
          </div>
        </div>
      `).join('');
    }

    // Fall Incident History Table
    const historyTable = document.getElementById('caregiver-fall-history-body');
    if (historyTable) {
      historyTable.innerHTML = (window.store.state.fallDetection.history || []).map(item => `
        <tr>
          <td><strong>${item.time}</strong></td>
          <td><span style="font-weight:600; color:${item.type.includes('CONFIRMED') ? 'var(--danger)' : 'var(--text-primary)'};">${item.type}</span></td>
          <td>${item.gForce}</td>
          <td>${item.actionTaken}</td>
          <td><span class="med-badge" style="background:${item.status.includes('Active') ? '#fee2e2' : '#d1fae5'}; color:${item.status.includes('Active') ? '#991b1b' : '#065f46'};">${item.status}</span></td>
        </tr>
      `).join('');
    }
  }
}

// Global instance
window.caregiverPortal = new CaregiverPortal();
