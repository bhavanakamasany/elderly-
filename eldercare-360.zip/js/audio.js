/**
 * ElderCare 360 - Audio & Voice Synthesis Service
 * Uses Web Audio API for synthetic sound effects without any external MP3 files,
 * plus Web Speech API for voice prompts for elderly users.
 */

class AudioService {
  constructor() {
    this.audioCtx = null;
    this.soundEnabled = true;
    this.voiceEnabled = true;
    this.currentAlarmInterval = null;
  }

  init() {
    if (!this.audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        this.audioCtx = new AudioContext();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  // Play a simple frequency tone
  playTone(freq, type = 'sine', duration = 0.2, volume = 0.15) {
    if (!this.soundEnabled) return;
    try {
      this.init();
      if (!this.audioCtx) return;

      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.audioCtx.currentTime);

      gain.gain.setValueAtTime(volume, this.audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start();
      osc.stop(this.audioCtx.currentTime + duration);
    } catch (e) {
      console.warn('Audio tone error:', e);
    }
  }

  // Pleasant chime for medication and routine reminders
  playChime() {
    if (!this.soundEnabled) return;
    try {
      this.init();
      const now = this.audioCtx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
      notes.forEach((freq, i) => {
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.12);
        gain.gain.setValueAtTime(0.18, now + i * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.12 + 0.4);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now + i * 0.12);
        osc.stop(now + i * 0.12 + 0.45);
      });
    } catch (e) {
      console.warn(e);
    }
  }

  // Success soothing chime (when senior presses "I am OK")
  playSuccess() {
    if (!this.soundEnabled) return;
    try {
      this.init();
      const now = this.audioCtx.currentTime;
      [440, 554.37, 659.25].forEach((freq, idx) => {
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.15);
        gain.gain.setValueAtTime(0.2, now + idx * 0.15);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.15 + 0.5);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now + idx * 0.15);
        osc.stop(now + idx * 0.15 + 0.55);
      });
    } catch (e) {
      console.warn(e);
    }
  }

  // Emergency countdown beep (accelerates in urgency)
  playCountdownBeep(secondsLeft) {
    if (!this.soundEnabled) return;
    try {
      this.init();
      const freq = secondsLeft <= 5 ? 880 : 587.33; // High pitch near end
      const duration = secondsLeft <= 5 ? 0.35 : 0.2;
      this.playTone(freq, 'sawtooth', duration, 0.25);
    } catch (e) {
      console.warn(e);
    }
  }

  // Emergency Siren Alarm (when SOS triggers)
  startEmergencyAlarm() {
    this.stopEmergencyAlarm();
    if (!this.soundEnabled) return;

    let toggle = false;
    this.currentAlarmInterval = setInterval(() => {
      this.playTone(toggle ? 850 : 620, 'square', 0.25, 0.28);
      toggle = !toggle;
    }, 320);
  }

  stopEmergencyAlarm() {
    if (this.currentAlarmInterval) {
      clearInterval(this.currentAlarmInterval);
      this.currentAlarmInterval = null;
    }
  }

  // Elderly voice prompts via Web Speech Synthesis
  speak(text) {
    if (!this.voiceEnabled) return;
    if (!('speechSynthesis' in window)) return;

    try {
      window.speechSynthesis.cancel(); // Cancel any ongoing speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.92; // Slightly slower, clear cadence for seniors
      utterance.pitch = 1.05;
      utterance.volume = 1;

      // Select natural English voice if available
      const voices = window.speechSynthesis.getVoices();
      const naturalVoice = voices.find(v => (v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('David') || v.name.includes('Zira'))));
      if (naturalVoice) {
        utterance.voice = naturalVoice;
      }
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
    }
  }
}

// Global audio singleton
window.audioService = new AudioService();
