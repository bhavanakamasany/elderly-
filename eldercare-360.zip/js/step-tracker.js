/**
 * ElderCare 360 - Step & Daily Activity Tracking Module
 */

class StepTracker {
  constructor() {
    this.canvasWeekly = null;
    this.bindEvents();
  }

  bindEvents() {
    const simStepBtn = document.getElementById('btn-sim-walk-steps');
    if (simStepBtn) {
      simStepBtn.addEventListener('click', () => this.simulateSteps(250));
    }

    const resetGoalBtn = document.getElementById('btn-edit-step-goal');
    if (resetGoalBtn) {
      resetGoalBtn.addEventListener('click', () => {
        const newGoal = prompt('Enter new daily step goal:', window.store.state.steps.goal);
        if (newGoal && !isNaN(newGoal) && Number(newGoal) > 0) {
          window.store.state.steps.goal = Number(newGoal);
          window.store.saveState();
          this.render();
          window.showToast(`Daily step goal updated to ${newGoal} steps!`, 'info');
        }
      });
    }
  }

  simulateSteps(addedSteps = 250) {
    const s = window.store.state.steps;
    const oldSteps = s.current;
    s.current += addedSteps;

    // Recalculate distance and calories (Senior avg: 1 step ~ 0.68m, 1000 steps ~ 42 kcal)
    s.distanceKm = Number((s.current * 0.00068).toFixed(2));
    s.caloriesBurned = Math.round(s.current * 0.042);
    s.activeMinutes = Math.min(Math.round(s.current / 110), 120);

    // Update Sunday (today in weekly)
    const sundayEntry = s.weekly.find(w => w.day === 'Sun');
    if (sundayEntry) {
      sundayEntry.steps = s.current;
    }

    // Check goal milestone
    if (oldSteps < s.goal && s.current >= s.goal) {
      window.audioService.playSuccess();
      window.audioService.speak('Congratulations Arthur! You have achieved your daily 6,000 steps goal!');
      window.store.addNotification('Daily Step Goal Achieved! 🏆', `Arthur reached ${s.current} steps today!`, 'success', '🏆');
      window.showToast('🎉 Goal Achieved! 6,000 steps completed today!', 'success', 5000);
    } else {
      window.audioService.playTone(600, 'sine', 0.1, 0.08);
      window.showToast(`Walk logged! +${addedSteps} steps added.`, 'info');
    }

    window.store.saveState();
    this.render();
  }

  render() {
    const s = window.store.state.steps;
    if (!s) return;

    // Elements
    const stepCountEls = document.querySelectorAll('.step-count-val');
    stepCountEls.forEach(el => el.textContent = s.current.toLocaleString());

    const goalEls = document.querySelectorAll('.step-goal-val');
    goalEls.forEach(el => el.textContent = s.goal.toLocaleString());

    const distEls = document.querySelectorAll('.step-distance-val');
    distEls.forEach(el => el.textContent = s.distanceKm + ' km');

    const calEls = document.querySelectorAll('.step-calories-val');
    calEls.forEach(el => el.textContent = s.caloriesBurned + ' kcal');

    const activeMinEls = document.querySelectorAll('.step-active-min-val');
    activeMinEls.forEach(el => el.textContent = s.activeMinutes + ' mins');

    // Progress percentage
    const pct = Math.min(Math.round((s.current / s.goal) * 100), 100);
    const pctEls = document.querySelectorAll('.step-pct-val');
    pctEls.forEach(el => el.textContent = pct + '%');

    // SVG Circle gauge
    const circle = document.getElementById('step-progress-circle-bar');
    if (circle) {
      const circumference = 2 * Math.PI * 45; // r = 45 => ~282.7
      const offset = circumference * (1 - (s.current / s.goal));
      circle.style.strokeDasharray = circumference;
      circle.style.strokeDashoffset = Math.max(offset, 0);
    }

    this.renderWeeklyChart();
  }

  renderWeeklyChart() {
    const canvas = document.getElementById('weekly-steps-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    const data = window.store.state.steps.weekly || [];
    const maxVal = Math.max(...data.map(d => d.steps), 7000);

    const barWidth = 28;
    const spacing = (w - (data.length * barWidth)) / (data.length + 1);

    // Goal line
    const goalY = h - 35 - ((window.store.state.steps.goal / maxVal) * (h - 60));
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(10, goalY);
    ctx.lineTo(w - 10, goalY);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = 'rgba(239, 68, 68, 0.7)';
    ctx.font = '10px sans-serif';
    ctx.fillText('Goal 6k', w - 45, goalY - 4);

    data.forEach((item, idx) => {
      const x = spacing + idx * (barWidth + spacing);
      const barH = (item.steps / maxVal) * (h - 60);
      const y = h - 30 - barH;

      const isToday = item.day === 'Sun';

      // Bar gradient
      const grad = ctx.createLinearGradient(0, y, 0, h - 30);
      if (isToday) {
        grad.addColorStop(0, '#0284c7');
        grad.addColorStop(1, '#0d9488');
      } else {
        grad.addColorStop(0, '#94a3b8');
        grad.addColorStop(1, '#cbd5e1');
      }

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.roundRect(x, y, barWidth, barH, [4, 4, 0, 0]);
      ctx.fill();

      // Text Day label
      ctx.fillStyle = isToday ? '#0284c7' : '#64748b';
      ctx.font = isToday ? 'bold 11px sans-serif' : '11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(item.day, x + (barWidth / 2), h - 12);

      // Text Steps count above bar
      ctx.fillStyle = '#475569';
      ctx.font = '10px sans-serif';
      ctx.fillText((item.steps / 1000).toFixed(1) + 'k', x + (barWidth / 2), y - 5);
    });
  }
}

// Global instance
window.stepTracker = new StepTracker();
